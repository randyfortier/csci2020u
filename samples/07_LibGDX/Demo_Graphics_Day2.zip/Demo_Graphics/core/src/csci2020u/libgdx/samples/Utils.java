package csci2020u.libgdx.samples;

public class Utils {
    public static final float WORLD_TO_SCREEN = 70;
}
