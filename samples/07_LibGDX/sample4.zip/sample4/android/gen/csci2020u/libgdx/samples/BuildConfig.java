/*___Generated_by_IDEA___*/

package csci2020u.libgdx.samples;

/* This stub is only used by the IDE. It is NOT the BuildConfig class actually packed into the APK */
public final class BuildConfig {
  public final static boolean DEBUG = Boolean.parseBoolean(null);
}