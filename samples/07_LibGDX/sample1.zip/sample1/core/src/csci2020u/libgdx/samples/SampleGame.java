package csci2020u.libgdx.samples;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.ai.steer.behaviors.Arrive;
import com.badlogic.gdx.ai.steer.behaviors.Hide;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.controllers.Controllers;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.box2d.*;

import static csci2020u.libgdx.samples.Utils.WORLD_TO_SCREEN;

/**
 * Creating a few textures to draw on the screen
 */
public class SampleGame extends ApplicationAdapter {
	public static float SCALE = 1.0f;

	private OrthographicCamera camera;

	// graphics
	private SpriteBatch batch;
	private Texture largePlatformTexture;
	private Texture smallPlatformTexture;
	private Texture playerTexture;

	// locations
	private float playerX = 200;
	private float playerY = 100;
	private float platform1X = 0;
	private float platform1Y = 0;
	private float platform2X = 400;
	private float platform2Y = 250;
	private float platform3X = 300;
	private float platform3Y = 500;
	private float platform4X = 400;
	private float platform4Y = 750;
	private float platform5X = 300;
	private float platform5Y = 1000;


	@Override
	public void create() {
		camera = new OrthographicCamera();
		camera.setToOrtho(false, Gdx.graphics.getWidth() / SCALE, Gdx.graphics.getHeight() / SCALE);

		batch = new SpriteBatch();
		largePlatformTexture = new Texture("images/large_platform.png");
		smallPlatformTexture = new Texture("images/small_platform.png");
		playerTexture = new Texture("images/hero.png");
	}

	@Override
	public void render() {
		// draw
		Gdx.gl.glClearColor(0f, 0f, 0f, 1f);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

		batch.begin();
		batch.draw(largePlatformTexture, platform1X - (largePlatformTexture.getWidth() / 2),
				                         platform1Y - (largePlatformTexture.getHeight() / 2));
		batch.draw(smallPlatformTexture, platform2X - (smallPlatformTexture.getWidth() / 2),
				                         platform2Y - (smallPlatformTexture.getHeight() / 2));
		batch.draw(smallPlatformTexture, platform3X - (smallPlatformTexture.getWidth() / 2),
				                         platform3Y - (smallPlatformTexture.getHeight() / 2));
		batch.draw(smallPlatformTexture, platform4X - (smallPlatformTexture.getWidth() / 2),
				                         platform4Y - (smallPlatformTexture.getHeight() / 2));
		batch.draw(smallPlatformTexture, platform5X - (smallPlatformTexture.getWidth() / 2),
				                         platform5Y - (smallPlatformTexture.getHeight() / 2));
		batch.draw(playerTexture, playerX - (playerTexture.getWidth() / 2),
				                  playerY - (playerTexture.getHeight() / 2));
		batch.end();

		//box2dRenderer.render(world, camera.combined.scl(WORLD_TO_SCREEN));

		if(Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)) Gdx.app.exit();
	}

	@Override
	public void resize(int width, int height) {
		camera.setToOrtho(false, width / SCALE, height / SCALE);
	}

	@Override
	public void dispose() {
		batch.dispose();
	}
}
