# User interfaces
- start IntelliJ IDEA
- create a new project
- select JavaFX
- under Project SDK, select new, JDK, select folder
- Project name:  03_user_interfaces_1
- Project location:  ~/csci2020u/03_user_interfaces_1
- delete .fxml and Controller files (for the first example)
- add a new file:  build.gradle (at root)
  apply plugin: 'java'

Run -> Run Configurations -> New -> Gradle (select build script, classes task)
